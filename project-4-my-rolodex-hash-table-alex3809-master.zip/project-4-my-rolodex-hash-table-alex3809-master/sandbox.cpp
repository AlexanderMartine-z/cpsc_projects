
/**
 * You don't need to edit this file, although you can if you wish.
 * This source file will not be graded.
 * 
 * This is just an extra program you can use to debug your code.
 * Put whatever you want here, and use "make sandbox" to execute it.
 */

//
#include <iostream>


//
using std::cout, std::cin, std::endl;


//
int main()
{
	//
	cout << "Hi. Put anything here you'd like." << endl;
	std::string str = "Hello";
	unsigned long long sum = 1;
				for(char char_ : str) {
					auto rep = static_cast<unsigned long long>(char_);
					sum = sum * rep;
					std::cout << rep << " : " << sum << endl;
					if(sum > 4294967295) {
						sum = sum % 4294967295;
					}
				}
				std::cout << sum << endl;
				sum = sum * sum;
				std::string sum_string = std::to_string(sum) ;
				std::cout << sum_string << endl;
				size_t pos = sum_string.size()/4;
				size_t length = sum_string.size()/2;
				std::string sub = sum_string.substr(pos,length);
				std::string y = sub;
				std::cout << y << endl;
				unsigned long long sum_num = std::stoull(y);
				std::cout << sum_num << endl;
				sum_num = sum_num % 100000;
				std::cout << sum_num << endl;
  	


	return 0;
}

